# ClashAdda — Free Fire Tournament Starter Project

This is a source-code starter for a Free Fire / Free Fire MAX tournament system:
- Responsive admin website (Firebase Web SDK integration scaffold)
- Android app starter (Kotlin + Jetpack Compose)
- Firestore security rules
- Cloud Functions TypeScript scaffold
- Setup guide

## Honest status
This is source code, not a compiled/signed APK and not a deployed, live Firebase website. It requires your own Firebase project configuration, dependencies, testing, and build steps. No real payments are processed. Do not launch paid tournaments until payment, legal, age, refund/dispute, game publisher policy, and security reviews are complete.

## 1. Firebase setup
Use your existing Firebase project ID `clashadda-b3e57`.
1. In Firebase Console, enable Authentication (Email/Password initially).
2. Create Firestore Database.
3. Register the web app and Android app in the same project.
4. Put the web app's public Firebase config in `web/firebase-config.example.js` (copy to `firebase-config.js` and fill values).
5. Download `google-services.json` for the Android app and place it in `android/app/`.
6. Never place a service-account private key in web or Android code. If a private key was exposed, revoke it in Google Cloud IAM.
7. Deploy rules: `firebase deploy --only firestore:rules`
8. Deploy functions from `functions/` after `npm install` and `firebase init functions`.

## 2. Web admin
Open `web/index.html` through a local web server (not file:// if Firebase modules are used). The UI is a starter; login uses Firebase Authentication. Admin access must be granted using a trusted server/Admin SDK custom claim (`admin: true`), never by a client-editable field. A Firebase project owner can use a secure one-off Admin SDK script in a trusted environment to set the claim.

For a simple local preview without Firebase config, open `web/demo.html`. Demo changes are not persisted.

## 3. Android
Open `android/` in Android Studio. Add your `google-services.json` under `android/app/`. Gradle files are a minimal starter and may need plugin version updates based on your installed Android Studio. Build > Build Bundle(s) / APK(s) > Build APK(s). For release distribution, create a signed build and keep the signing key private.

## 4. Firestore data model
- `users/{uid}` — public profile fields; roles are custom claims, not user-editable profile values.
- `tournaments/{id}` — name, mode (`Solo`, `Duo`, `Squad`), map, entryFee, prizePool, maxSlots, joinedCount, startAt, status.
- `tournaments/{id}/registrations/{uid}` — player/team registration.
- `tournaments/{id}/privateRoom/{roomDoc}` — room ID/password; server/admin-only reads.
- `tournaments/{id}/results/{resultId}` — verified result details.
- `transactions/{id}` — server-created payment ledger.
- `auditLogs/{id}` — server-created audit log.

## 5. Production security checklist
- Keep admin role in Firebase Auth custom claims, set only with Admin SDK.
- Keep wallet balance, payments, prize payout, registration slot reservation and winner declaration server-side.
- Verify payment provider webhooks on the server; never trust a client success screen.
- Use App Check, rate limits, abuse controls and audit logs.
- Room passwords should only be released to approved participants near match time.
- Add privacy policy, terms, support and refund/dispute procedures.
