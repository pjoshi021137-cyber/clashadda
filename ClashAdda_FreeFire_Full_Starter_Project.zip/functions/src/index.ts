import { onCall, HttpsError } from "firebase-functions/v2/https";
import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { getAuth } from "firebase-admin/auth";

initializeApp();
const db = getFirestore();
function requireAdmin(request: any) {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "Admin access required.");
  }
}

// Run only from a trusted environment after verifying the target user.
// Never expose an endpoint that lets a caller grant themselves this claim.
export const setAdminClaim = onCall(async (request) => {
  requireAdmin(request);
  const uid = String(request.data?.uid || "");
  if (!uid) throw new HttpsError("invalid-argument", "uid is required.");
  await getAuth().setCustomUserClaims(uid, { admin: true });
  await db.collection("auditLogs").add({
    actorUid: request.auth!.uid, action: "set_admin_claim", targetId: uid,
    createdAt: FieldValue.serverTimestamp()
  });
  return { ok: true };
});

// Atomic slot reservation starter. Paid-entry payment verification must happen
// server-side before allowing paid registrations; this function deliberately
// rejects paid tournaments until a payment provider webhook is integrated.
export const registerForTournament = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in first.");
  const uid = request.auth.uid;
  const tournamentId = String(request.data?.tournamentId || "");
  if (!tournamentId) throw new HttpsError("invalid-argument", "Tournament ID required.");
  const tRef = db.collection("tournaments").doc(tournamentId);
  const rRef = tRef.collection("registrations").doc(uid);
  await db.runTransaction(async tx => {
    const tSnap = await tx.get(tRef);
    if (!tSnap.exists) throw new HttpsError("not-found", "Tournament not found.");
    const t = tSnap.data()!;
    if (t.status !== "open") throw new HttpsError("failed-precondition", "Tournament is not open.");
    if (Number(t.entryFee || 0) > 0) {
      throw new HttpsError("failed-precondition", "Paid entry is disabled until server-side payment verification is configured.");
    }
    if (tx.get && (await tx.get(rRef)).exists) throw new HttpsError("already-exists", "Already registered.");
    const joined = Number(t.joinedCount || 0), max = Number(t.maxSlots || 0);
    if (max < 1 || joined >= max) throw new HttpsError("resource-exhausted", "No slots available.");
    tx.create(rRef, { uid, status: "pending", createdAt: FieldValue.serverTimestamp() });
    tx.update(tRef, { joinedCount: joined + 1 });
    tx.set(db.collection("auditLogs").doc(), {
      actorUid: uid, action: "register_tournament", targetId: tournamentId,
      createdAt: FieldValue.serverTimestamp()
    });
  });
  return { ok: true, status: "pending" };
});
