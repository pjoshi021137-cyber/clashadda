package com.clashadda.freefire

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090B12)
private val Panel = Color(0xFF171B29)
private val Gold = Color(0xFFFFB629)
private val Muted = Color(0xFF9BA4B9)

data class Tournament(val name: String, val mode: String, val map: String, val fee: String, val prize: String, val slots: String)
private val demoTournaments = listOf(
    Tournament("ClashAdda Booyah Cup", "Squad", "Bermuda", "₹20", "₹3,000", "36/48 slots"),
    Tournament("Solo Rush Challenge", "Solo", "Kalahari", "₹10", "₹1,000", "41/48 slots"),
    Tournament("Duo Night Scrims", "Duo", "Purgatory", "Free", "₹500", "18/24 slots")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClashAddaApp() }
    }
}

@Composable
fun ClashAddaApp() {
    var tab by remember { mutableStateOf("Tournaments") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = Panel)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home", "Tournaments", "My Matches", "Profile").forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item },
                        icon = { Text(when(item) { "Home" -> "⌂"; "Tournaments" -> "⚔"; "My Matches" -> "▣"; else -> "♙" }) },
                        label = { Text(item, fontSize = 10.sp) })
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().background(Bg).padding(padding).padding(horizontal = 18.dp, vertical = 14.dp)) {
                Text("CLASH", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                Text("ADDA  •  FREE FIRE TOURNAMENTS", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(22.dp))
                when (tab) {
                    "Home" -> {
                        Text("READY TO BOOYAH?", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(8.dp))
                        Text("Join Free Fire tournaments, check match details and track your results.", color = Muted)
                        Spacer(Modifier.height(18.dp))
                        Button(onClick = { tab = "Tournaments" }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("Explore tournaments", color = Bg) }
                    }
                    "My Matches" -> {
                        Text("MY MATCHES", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Sign-in and live registrations will appear here after Firebase Auth and Firestore are configured.", color = Muted)
                    }
                    "Profile" -> {
                        Text("PLAYER PROFILE", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Firebase login, Free Fire UID and account settings are not configured in this starter.", color = Muted)
                    }
                    else -> {
                        Text("LIVE & UPCOMING", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Find your next Free Fire match", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(demoTournaments) { t ->
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(Modifier.size(42.dp).background(Gold, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                                                Text("FF", color = Bg, fontWeight = FontWeight.Black)
                                            }
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(t.name, color = Color.White, fontWeight = FontWeight.Bold)
                                                Text("${t.mode} • ${t.map}", color = Muted, fontSize = 12.sp)
                                            }
                                            Text(t.fee, color = Gold, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(Modifier.height(16.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f)) {
                                                Text("PRIZE POOL", color = Muted, fontSize = 10.sp)
                                                Text(t.prize, color = Color.White, fontWeight = FontWeight.Bold)
                                            }
                                            Column(Modifier.weight(1f)) {
                                                Text("SLOTS", color = Muted, fontSize = 10.sp)
                                                Text(t.slots, color = Color.White, fontWeight = FontWeight.Bold)
                                            }
                                            OutlinedButton(onClick = { }, enabled = false) { Text("Coming soon") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
